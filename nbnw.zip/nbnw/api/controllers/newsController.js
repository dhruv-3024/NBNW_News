const fetch = require("node-fetch");

const get5Headlines = async () => {
  try {
    let url = `https://newsapi.org/v2/top-headlines?country=in&apiKey=${process.env.NEWS_API_KEY}`;
    const resp = await fetch(url); //fetch data from news api
    const data = await resp.json(); 
    if (data.status === "ok") {
      // slicing first 5 headlines from api response and adding to array headlines for respective article
      const headlines = data.articles.slice(0, 5).map((article) => ({
        title: article.title,
        source: article.source.name,
        publishedAt: article.publishedAt,
        image: article.urlToImage,
        description: article.discription,
        author: article.author,
        content: article.content,
        url: article.url,
      }));
      return headlines;
    } else {
      throw new Error(data.message || "Failed to fetch headlines");
    }
  } catch (err) {
    throw new Error("Error fetching headlines");
  }
};

module.exports = {
  get5Headlines,
};
