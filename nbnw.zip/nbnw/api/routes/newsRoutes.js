const express = require('express');
const router = express.Router();
const { get5Headlines } = require('../controllers/newsController');

// Route to fetch 5 latest news headlines, as the page loads top 5 headlines are displayed in the latest news section
router.get('/', async (req, res) => {
  try {
    const headlines = await get5Headlines();
    res.json(headlines);
  } catch (error) {
    console.error('Error fetching headlines:', error);
    res.status(404).send({
      message: 'Error occurred while fetching headlines'
    });
  }
});

module.exports = router;
