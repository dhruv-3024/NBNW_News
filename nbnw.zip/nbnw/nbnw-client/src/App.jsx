import "./App.css";
import Navbar from "./components/Navbar";
import Banner from "./components/Banner";
import Footer from "./components/Footer";
import LatestNews from "./pages/home/LatestNews";

function App() {
  return (
    <>
      <Navbar />
      <Banner />
      <LatestNews/>
      <Footer />
    </>
  );
}

export default App;
