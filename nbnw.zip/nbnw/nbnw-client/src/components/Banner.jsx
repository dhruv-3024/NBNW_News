import React from "react";

const Banner = () => {
  return (
    
    <div className="section-container pt-[100px] p-[50px] m-5 bg-slate-100">
      <p>
        "Stay Informed, Stay Ahead: Your Source for Timely News and Insights!
        Welcome to NBNW, where we deliver the latest updates,
        compelling stories, and in-depth analyses that matter most to you. From
        breaking news to in-depth features across politics, technology, health,
        and beyond, we strive to provide you with accurate, unbiased reporting
        that empowers and informs. Join us as we navigate the complexities of
        today's world, bringing you the news that shapes tomorrow."
      </p>
    </div>
  );
};

export default Banner;
