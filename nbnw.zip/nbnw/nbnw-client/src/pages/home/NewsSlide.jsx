import React from "react";
import { Link } from "react-router-dom";

/* Here ,in NewsSlide component we are getting headline prop from LatestNews.jsx, 
based on the no. of headlines news slide will be added accordingly */
const NewsSlide = ({ headline }) => {
  return (
    <div className="carousel-item w-full">
      
        <div className="card lg:card-side shadow-xl w-full p-4 bg-slate-100">
          <figure className="">
            {
              // If there is a featured image, display it else use the default image
              headline.image ? (
                <img
                  className=" rounded-md "
                  src={headline.image}
                  alt=""
                />
              ) : (
                <img
                  className="rounded-md "
                  src="../images/default-news-img.png"
                  alt="Album"
                />
              )
            }
          </figure>
          <div className="card-body">
            <h2>{headline.title}</h2>
            <p>{headline.content}<br/>
            <a href={headline.url} className="link ">Read More...</a>
            </p>
            <div>
              Source:
              <span className="badge">{headline.source}</span>{" "}
              <span className="badge">
                <time>{new Date(headline.publishedAt).toLocaleString()}</time>
              </span>{" "}
            </div>
          </div>
        </div>
      
    </div>
  );
};

export default NewsSlide;
