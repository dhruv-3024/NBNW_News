import React, { useState, useEffect } from "react";
import NewsSlide from "./NewsSlide";

const LatestNews = () => {
  const [headlines, setHeadlines] = useState([]);

  // Fetch data as soon as the page loads, we use useEffect() as it executes directly when page loads
  useEffect(() => {
    fetchHeadlines();
  }, []);

/* fetchHeadlines method fetches data from backend via this path as set in the backend. 
  Api data is fetched in the backend and from there we fetch data to the frontend using the https://localhost:3300/ path */
  const fetchHeadlines = async () => {
    try {
      const response = await fetch("http://localhost:3300/");
      const data = await response.json();
      setHeadlines(data);
    } catch (error) {
      console.error("Error fetching headlines:", error.message);
    }
  };
  // console.log(headlines);
  return (
    <div className="section-container">
      <div className="carousel w-full  ">
        {headlines.map((headline, index) => (
          <NewsSlide key={index} headline={headline} />
        ))}
      </div>
    </div>
  );
};

export default LatestNews;
