1. Open project in VS Code

2. open new terminal and run command : npm install
   eg. ..\nbnw>npm install or npm i

   This command will install all the necessary project dependencies.
   \*Node.js should be installed first

3)For starting the backend run command: npm start

4)For starting the frontend, (open new terminal)
1)run command : cd nbnw-client (cd is used to change dir.)
eg. ..\nbnw>cd nbnw-client
2)after changing dir, run command: npm run dev
eg. ..\nbnw\nbnw-client>npm run dev

5)After running the frontend, a link will be displayed in the terminal, click on it to open in browser


